# Celsius-to-Fahrenheit-using-ANN
Development of a Neural Network Model to convert Celsius to Fahrenheit using ANN in google colab
